package bet.notification.enums;

public enum PrizeStatus {
    PENDING,
    CONFIRMED
}
