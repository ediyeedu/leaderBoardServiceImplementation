package org.kabbee.PredictionService.service.dto;

public enum QuestionType {
    COUNT,
    TIME,
    PLAYER,
    TEAM
}
