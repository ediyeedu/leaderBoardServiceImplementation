package org.kabbee.PredictionService.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class EventSender {


//    @Autowired
//    private KafkaTemplate<String, PredictionListEvent> kafkaTemplate;
//
//    public void sendTopUsers(PredictionListEvent message) {
//        kafkaTemplate.send("prediction-topic", message);
//
//    }

}
