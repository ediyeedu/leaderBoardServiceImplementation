package org.kabbee.PredictionService.service.dto;

public enum QuestionScope {
    TOURNAMENT,
    MATCH
}
