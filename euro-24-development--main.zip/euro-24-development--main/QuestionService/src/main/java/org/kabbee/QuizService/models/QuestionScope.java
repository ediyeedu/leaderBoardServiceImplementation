package org.kabbee.QuizService.models;

public enum QuestionScope {
 TOURNAMENT, MATCH
}
