package org.kabbee.QuizService.models;

public enum QuestionType {
  COUNT, TEAM, PLAYER, TIME
}
