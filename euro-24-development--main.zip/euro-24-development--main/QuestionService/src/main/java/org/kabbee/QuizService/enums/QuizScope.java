package org.kabbee.QuizService.enums;


public enum QuizScope {

    HISTORICAL, MATCH, TOURNAMENT
}
