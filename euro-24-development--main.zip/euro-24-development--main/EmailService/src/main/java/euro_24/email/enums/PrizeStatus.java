package euro_24.email.enums;

public enum PrizeStatus {
    PENDING,
    CONFIRMED,
    DELIVERED
}
