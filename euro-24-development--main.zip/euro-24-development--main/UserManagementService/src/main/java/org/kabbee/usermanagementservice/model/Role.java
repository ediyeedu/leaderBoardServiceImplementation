package org.kabbee.usermanagementservice.model;

public enum Role {
    USER,
    ADMIN
}
