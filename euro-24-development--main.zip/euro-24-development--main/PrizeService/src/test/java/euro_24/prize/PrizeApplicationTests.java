package euro_24.prize;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrizeApplicationTests {

	@Test
	void contextLoads() {
	}

}
