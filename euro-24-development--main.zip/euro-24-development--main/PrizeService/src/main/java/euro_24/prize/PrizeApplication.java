package euro_24.prize;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrizeApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrizeApplication.class, args);
	}

}
