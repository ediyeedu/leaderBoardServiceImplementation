package euro_24.prize.enums;

public enum PrizeStatus {
    PENDING,
    CONFIRMED,
    DELIVERED
}
