package euro_24.prize.enums;

public enum QuizScope {

     MATCH, TOURNAMENT
}
